1. After downloading the extension folder you should open up your browsers extension tab (if on chrome type in chrome://extensions in the searchbar).
2. Then turn on developer mode in top right corner of the extensions page.
3. Click the load unpackaged in the top left corner.
4. Choose the extension folder that you have just downloaded.
5. The extension is now installed and is listed with the other active extensions in your browser.