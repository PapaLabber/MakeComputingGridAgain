After downloading the extension folder you should open up your browsers extension tab (if on chrome type in chrome://extensions in the searchbar.
Then turn on developer mode in top right corner of the extensions page
Once this is done, click the load unpackaged in the top left corner
Choose the extension folder that you have just downloaded.
Once this is done, the extension has been installed and is ready to run.